package com.project.ecommerc.mart247.controller.client;

import org.springframework.stereotype.Controller;

@Controller
public class PaymentClientController {

}
