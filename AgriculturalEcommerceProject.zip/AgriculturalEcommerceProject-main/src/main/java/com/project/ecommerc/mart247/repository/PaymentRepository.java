package com.project.ecommerc.mart247.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.ecommerc.mart247.entity.PaymentEntity;

public interface PaymentRepository  extends JpaRepository<PaymentEntity, Long>{

}
