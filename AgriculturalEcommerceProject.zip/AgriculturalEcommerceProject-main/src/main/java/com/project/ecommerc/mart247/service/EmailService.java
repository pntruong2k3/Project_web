package com.project.ecommerc.mart247.service;

public interface EmailService {

	   

	    void sendEmail(String EmailTo, String emailSubject, String emailContent);
}
