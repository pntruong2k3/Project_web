User Account Management:
 - User: Register, Login, Change Password
 
 - Admin: Deactive Account

Products Management:
 - User: Search Product, Show All Products, Show Products
by Category, Product Details

 - Admin: Add Product, Update Product, Change Status Product

 - Shopping Cart: Add Item to Cart, Change Quantity Item, Delete
Item

Order:
 - User: Create Order, Check Out with Payment Card or COD
   
 - Admin: Show List Order, Order Detail, Change Order Status

Tech: Spring MVC, Spring Data JPA, Spring Security, Spring Mail,
Hibernate, Thymeleaf, MySQL, Jquery, Javascript, Bootstrap

